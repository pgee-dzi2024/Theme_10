from django.apps import AppConfig


class CustomerPortalConfig(AppConfig):
    name = 'customer_portal'
